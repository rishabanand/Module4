package com.cg.springdemotwo.dto;

public class Employee implements EmployeeDetail
{
	private int empId;
	private String empName;
	
	public Employee() 
	{
		super();	
	}
	

	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}


	@Override
	public void getAllEmployeeDetail() 
	{
		System.out.println("Id is "+empId);
		System.out.println("Name is "+empName);
		
	}

}
