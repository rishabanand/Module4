package com.cg.ui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.dto.Project;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.cg")
public class MyTest 
{

	private static ApplicationContext appContext;

	public static void main(String[] args) 
	{
		appContext = SpringApplication.run(MyTest.class);
		Project pr=(Project)appContext.getBean("proj");
		pr.getData();
	}

}
