package com.cg.springdemoone.dto;

public class Employee 
{
	private int empId;
	private String empName;

	public void getAllDetails()
	{
		System.out.println(" Employee Id is : "+empId);
		System.out.println(" Employee Name is : "+empName);
	}
	public int getEmpId() 
	{
		return empId;
	}
	public void setEmpId(int empId) 
	{
		this.empId = empId;
	}
	public String getEmpName() 
	{
		return empName;
	}
	public void setEmpName(String empName) 
	{
		this.empName = empName;
	}	
}
