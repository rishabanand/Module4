package com.cg.springdemoone.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//import com.cg.springdemoone.dto.Circle;
import com.cg.springdemoone.dto.Employee;
//import com.cg.springdemoone.dto.Shape;

public class MyTest 
{
	private static ApplicationContext appContext;

	public static void main(String[] args) 
	{
		appContext = new ClassPathXmlApplicationContext("Spring.xml");
		/*Shape shape=(Shape)appContext.getBean("tran");
		shape.getShape();
		Shape shape1=appContext.getBean("circle",Circle.class);
		shape1.getShape();*/
		Employee employee=(Employee)appContext.getBean("emp");
		employee.getAllDetails();
		
	}
}
