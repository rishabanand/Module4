package com.cg.springmvctwo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvctwo.dao.IMobileDao;
import com.cg.springmvctwo.dto.Mobile;
@Service("mobileService")
@Transactional
public class MobileServiceImpl implements IMobileService
{
	@Autowired
	IMobileDao mobileDao;

	@Override
	public List<Mobile> showAllMobile()
	{
	
		return mobileDao.showAllMobile();
	}

	@Override
	public void deleteMobile(int mobId)
	{
		mobileDao.deleteMobile(mobId);		
	}

	@Override
	public void updateMobile(Mobile mob)
	{
		mobileDao.updateMobile(mob);		
	}

}
