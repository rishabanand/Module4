package com.cg.springmvctwo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.springmvctwo.dto.Mobile;
import com.cg.springmvctwo.service.IMobileService;
@Controller
public class MobileController 
{
	@Autowired
	IMobileService mobileService;
	@RequestMapping(name="showAll",method=RequestMethod.GET)
	public ModelAndView getAllMobileData()
	{
		List<Mobile> mobData=mobileService.showAllMobile();
		System.out.println("Data is :"+mobData);
		return new ModelAndView("showAllMobile","temp",mobData);		
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String mobileDelete(@RequestParam("id") int mobId)
	{
		//System.out.println("Id is : "+mobId);
		mobileService.deleteMobile(mobId);
		return "redirect:/showAll";
	}
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String update(@RequestParam("id1") int mobId,@ModelAttribute("my") Mobile mob,Map<String,Integer> myMap)
	{
		myMap.put("id", mobId);
		//System.out.println("Id is : "+mobId);
		return "updateMobile";
	}
	@RequestMapping(value="update2",method=RequestMethod.GET)
	public String updateMobileName(@ModelAttribute("my") Mobile mob,@RequestParam("id") int Id)
	{
		//System.out.println("Data is: "+mob);
		mob.setMobId(Id);
		mobileService.updateMobile(mob);
		return "SuccessUpdate";
	}
}
