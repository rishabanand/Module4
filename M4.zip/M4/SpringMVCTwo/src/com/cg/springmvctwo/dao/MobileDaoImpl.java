package com.cg.springmvctwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvctwo.dto.Mobile;

@Repository("mobileDao")
public class MobileDaoImpl implements IMobileDao
{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<Mobile> showAllMobile() 
	{
		Query queryOne=entityManager.createQuery("FROM Mobile");
		List<Mobile> mobList=queryOne.getResultList();
		return mobList;
	}

	@Override
	public void deleteMobile(int mobId) 
	{
		Query queryTwo=entityManager.createQuery("DELETE FROM Mobile WHERE mobId=:mId");
		queryTwo.setParameter("mId",mobId);
		queryTwo.executeUpdate();
	}

	@Override
	public void updateMobile(Mobile mob) 
	{
		entityManager.merge(mob);
		entityManager.flush();
	}

}
