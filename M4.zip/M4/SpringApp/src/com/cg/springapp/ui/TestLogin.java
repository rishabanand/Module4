package com.cg.springapp.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.springapp.dto.Login;
public class TestLogin 
{

	private static ApplicationContext appContext;

	public static void main(String[] args) 
	{
		appContext = new ClassPathXmlApplicationContext("spring.xml");
		Login lo=(Login)appContext.getBean("login");
		lo.getLogin();

	}

}
