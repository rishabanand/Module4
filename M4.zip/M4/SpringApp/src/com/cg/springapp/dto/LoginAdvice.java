package com.cg.springapp.dto;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoginAdvice 
{
	@Before("execution(public void *Login())")
	public void beforeLogin()
	{
		System.out.println("Befor Login");
	}
	@After("execution(public void *Login())")
	public void afterLogin()
	{
		System.out.println("After Login");
	}
}
