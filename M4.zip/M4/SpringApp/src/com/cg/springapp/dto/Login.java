package com.cg.springapp.dto;

import org.springframework.stereotype.Component;

@Component
public class Login
{
	public void getLogin()
	{
		System.out.println("Hii Login");
	}
}
