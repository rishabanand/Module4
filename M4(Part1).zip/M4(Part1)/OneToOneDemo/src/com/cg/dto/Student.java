package com.cg.dto;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
//import javax.persistence.OneToOne;

@Entity
public class Student 
{
	@Id
	private int rollNo;
	private String studentName;
	@OneToMany(mappedBy="student",cascade=CascadeType.ALL)
	//@OneToOne(cascade=CascadeType.ALL)
	//@JoinColumn(name="addressId" )
	private Set<Address> address;
	public Student() 
	{
		super();
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}	
	
	public Student(int rollNo, String studentName, Set<Address> address)
	{
		super();
		this.rollNo = rollNo;
		this.studentName = studentName;
		this.address = address;
	}
	public Set<Address> getAddress() {
		return address;
	}
	public void setAddress(Set<Address> address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", studentName=" + studentName
				+ ", address=" + address + "]";
	}
	
}
