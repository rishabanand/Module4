package com.cg.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Address 
{
	@Id
	private int addressId;
	private String addressLine;
	private String city;
	//@OneToOne(mappedBy="address",cascade=CascadeType.ALL)
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="rollNo")
	private Student student;
	public Address() 
	{
		super();		
	}
	
	public Address(int addressId, String addressLine, String city,
			Student student) 
	{
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
		this.city = city;
		this.student = student;
	}

	public int getAddressId() 
	{
		return addressId;
	}
	public void setAddressId(int addressId) 
	{
		this.addressId = addressId;
	}
	public String getAddressLine() 
	{
		return addressLine;
	}
	public void setAddressLine(String addressLine)
	{
		this.addressLine = addressLine;
	}
	public String getCity() 
	{
		return city;
	}
	public void setCity(String city) 
	{
		this.city = city;
	}
	
	public Student getStudent()
	{
		return student;
	}
	public void setStudent(Student student) 
	{
		this.student = student;
	}
	@Override
	public String toString()
	{
		return "Addresss [addressId=" + addressId + ", addressLine="
				+ addressLine + ", city=" + city + "]";
	}
	
}
