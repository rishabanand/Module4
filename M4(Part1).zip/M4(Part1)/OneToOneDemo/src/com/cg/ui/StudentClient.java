package com.cg.ui;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Address;
import com.cg.dto.Student;

public class StudentClient 
{

	public static void main(String[] args) 
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		Address myAddress=new Address(101,"Talwade","Pune",null);
		Address myAddress1=new Address(102,"Hinjewadi","Pune",null);
		
		Set<Address> addSet=new HashSet<>();
		addSet.add(myAddress);
		addSet.add(myAddress1);
		
		Student student=new Student();
		student.setRollNo(1001);
		student.setStudentName("Rishab");
		student.setAddress(addSet);
		 
		myAddress.setStudent(student);
		myAddress1.setStudent(student);
		em.getTransaction().begin();
		em.persist(student);//em.persist(myAddress);
		em.getTransaction().commit();
		System.out.println("Student and address record Inserted");
	}

}
