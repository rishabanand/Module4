package com.cg.mpas.dao;

import java.util.List;

import com.cg.mpas.dto.Mobile;

public interface IMobileDao 
{
	public void addMobile(Mobile mobile);
	List<Mobile> showAllMobiles();
}
