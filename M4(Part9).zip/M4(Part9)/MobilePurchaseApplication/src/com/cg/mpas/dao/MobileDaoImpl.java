package com.cg.mpas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.mpas.dto.Mobile;

@Repository("mobileDao")
public class MobileDaoImpl implements IMobileDao 
{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public void addMobile(Mobile mobile) 
	{
		entityManager.persist(mobile);
		entityManager.flush();		
	}
	@Override
	public List<Mobile> showAllMobiles() 
	{
		Query queryOne=entityManager.createQuery("SELECT m FROM Mobile m");
		List<Mobile> myList= queryOne.getResultList();
	return myList;
	}
	
}
