package com.cg.mpas.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mpas.dto.Mobile;
import com.cg.mpas.service.IMobileService;



@Controller
public class MyController 
{
	@Autowired
	IMobileService mobileService;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "home";
	}
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my") Mobile mobile
			,Map<String,Object> model)
	{
		List<String> categories=new ArrayList<>();
		categories.add("Samsung");
		categories.add("iPhone");
		categories.add("Nokia");
		model.put("category",categories);
		return "addMobile";
	}
	@RequestMapping(value="insertData", method=RequestMethod.POST)
	public String insertMobile(@ModelAttribute("my") Mobile mobile)
	{		
		mobileService.addMobile(mobile);
		return "success";
	}
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showAllMobiles()
	{
		List<Mobile> myAllData=mobileService.showAllMobiles();
		return new ModelAndView("showAll", "temp", myAllData);
	}
}
