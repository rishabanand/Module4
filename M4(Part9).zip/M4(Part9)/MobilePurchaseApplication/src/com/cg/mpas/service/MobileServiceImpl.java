package com.cg.mpas.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mpas.dao.IMobileDao;
import com.cg.mpas.dto.Mobile;
@Service("mobileService")
@Transactional
public class MobileServiceImpl implements IMobileService
{
	@Autowired
	IMobileDao mobileDao;

	@Override
	public void addMobile(Mobile mobile) 
	{
		mobileDao.addMobile(mobile);		
	}

	@Override
	public List<Mobile> showAllMobiles() 
	{		
		return mobileDao.showAllMobiles();
	}

}
