package com.cg.gear.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="query_master")
public class Query 
{
	@Id
	@Column(name="query_id")
	private Integer queryId;
	private String technology;
	@Column(name="query_raised_by")
	@NotEmpty(message="This field should not be empty")
	private String queryRaised;
	@NotEmpty(message="This field should not be empty")
	private String query;
	@NotEmpty(message="Solution field should not kept blank")
	private String solutions;
	@Column(name="solution_given_by")
	private String solutionGiven;
	public Integer getQueryId() {
		return queryId;
	}
	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getQueryRaised() {
		return queryRaised;
	}
	public void setQueryRaised(String queryRaised) {
		this.queryRaised = queryRaised;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}
	public String getSolutionGiven() {
		return solutionGiven;
	}
	public void setSolutionGiven(String solutionGiven) {
		this.solutionGiven = solutionGiven;
	}
	
	
	
}
