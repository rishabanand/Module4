package com.cg.gear.dao;

import com.cg.gear.dto.Query;


public interface IGearDao 
{
	public Query fetchQueryById(int queryId);
	public void updateQuery(Query qry);
}
