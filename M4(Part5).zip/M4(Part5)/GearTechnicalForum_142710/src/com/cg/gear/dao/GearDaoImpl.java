package com.cg.gear.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.gear.dto.Query;

@Repository("gearDao")
public class GearDaoImpl implements IGearDao
{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public Query fetchQueryById(int queryId) 
	{
		Query query=entityManager.find(Query.class, queryId);
		return query;
	}
	@Override
	public void updateQuery(Query qry) {
		entityManager.merge(qry);
		entityManager.flush();
		
	}

}
