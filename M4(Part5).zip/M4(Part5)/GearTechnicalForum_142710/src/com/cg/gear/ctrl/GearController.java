package com.cg.gear.ctrl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.gear.dto.Query;
import com.cg.gear.service.IGearService;



@Controller
public class GearController 
{
	@Autowired
	IGearService gearservice;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "home";
	}
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public ModelAndView showAll(@RequestParam ("qid") int id,Map<String,Object> model)
	{
		Query qury=gearservice.fetchQueryById(id);
		{
		List<String> sme=new ArrayList<>();
		sme.add("Uma");
		sme.add("Rahul");
		sme.add("Kavita");
		sme.add("Hema");
		model.put("list", sme);
		return new ModelAndView("show","showList",qury);
		}
	}
}
