package com.cg.gear.service;

import com.cg.gear.dto.Query;

public interface IGearService
{
	public Query fetchQueryById(int queryId);
	public void updateQuery(Query qry);
}
