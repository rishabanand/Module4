package com.cg.gear.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.gear.dao.IGearDao;
import com.cg.gear.dto.Query;

@Service("gearservice")
@Transactional
public class GearServiceImpl implements IGearService
{
	@Autowired
	IGearDao gearDao;
	@Override
	public Query fetchQueryById(int queryId) 
	{
		return gearDao.fetchQueryById(queryId);
	}
	@Override
	public void updateQuery(Query qry) 
	{
		
		gearDao.updateQuery(qry);
	}

}
