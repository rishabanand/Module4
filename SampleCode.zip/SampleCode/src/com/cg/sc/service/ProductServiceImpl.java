package com.cg.sc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sc.dao.IProductDao;
import com.cg.sc.dto.Product;

@Service("productService")
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductDao productDao;
	@Override
	public List<Product> getAllProduct() 
	{
		return productDao.getAllProduct();
	}
	@Override
	public void updateProductById(Product product) {
		productDao.updateProductById(product);
	}
	@Override
	public Product fetchProductById(int productId) {
		return productDao.fetchProductById(productId);
	}

}
