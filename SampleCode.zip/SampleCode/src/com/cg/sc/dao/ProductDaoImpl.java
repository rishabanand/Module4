package com.cg.sc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.sc.dto.Product;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao
{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<Product> getAllProduct() 
	{
		Query query1=entityManager.createQuery("SELECT p FROM Product p");
		List<Product> pList=query1.getResultList();
		return pList;
	}
	@Override
	public void updateProductById(Product product) {
		entityManager.merge(product);
		entityManager.flush();
	}
	@Override
	public Product fetchProductById(int productId) 
	{
		Product product=entityManager.find(Product.class, productId);
		return product;
	}

}
