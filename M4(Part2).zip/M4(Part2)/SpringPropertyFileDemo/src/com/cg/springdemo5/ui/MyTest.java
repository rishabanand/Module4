package com.cg.springdemo5.ui;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemo5.dto.Employee;

public class MyTest {

	private static ApplicationContext appContext;

	public static void main(String[] args) 
	{
	
		appContext = new ClassPathXmlApplicationContext("Spring.xml");
		Employee e=(Employee)appContext.getBean("emp1",Employee.class);
		e.getAllData();
	}

}
