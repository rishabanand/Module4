package com.cg.springspo.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springspo.dto.PrintEmployeeDetail;

public class MyTest {

	public static void main(String[] args) 
	{
		ApplicationContext appContext=new ClassPathXmlApplicationContext("Spring.xml");
		PrintEmployeeDetail pemp=(PrintEmployeeDetail)appContext.getBean("print");
		pemp.getAllDetails();
	}

}
