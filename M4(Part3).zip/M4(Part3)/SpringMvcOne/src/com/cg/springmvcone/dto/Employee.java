package com.cg.springmvcone.dto; 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="employee_mgt")
public class Employee 
{
	@Id
	@SequenceGenerator(name="empIdSeq", sequenceName="emp_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="empIdSeq")
	@Column(name="emp_id")
	private Integer empId;
	@NotEmpty(message="Name should not be empty")
	@Column(name="emp_name")
	private String empName;
	@Column(name="emp_deg")
	private String empDesgination;
	@NotNull(message="Salary should not be empty")
	@Column(name="emp_sal")
	private Double empSalary;
	@Column(name="emp_gen")
	private String gender;
	public Integer getEmpId() 
	{
		return empId;
	}
	public void setEmpId(Integer empId) 
	{
		this.empId = empId;
	}
	public String getEmpName() 
	{
		return empName;
	}
	public void setEmpName(String empName) 
	{
		this.empName = empName;
	}
	public String getEmpDesgination()
	{
		return empDesgination;
	}
	public void setEmpDesgination(String empDesgination) 
	{
		this.empDesgination = empDesgination;
	}
	public Double getEmpSalary() 
	{
		return empSalary;
	}
	public void setEmpSalary(Double empSalary) 
	{
		this.empSalary = empSalary;
	}
	public String getGender() 
	{
		return gender;
	}
	public void setGender(String gender) 
	{
		this.gender = gender;
	}	
}
