package com.cg.springmvcone.service;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.springmvcone.dao.IEmployeeDao;
import com.cg.springmvcone.dto.Employee;
@Service("employeeService")
@Transactional

public class EmployeeServiceImpl implements IEmployeeService
{
	@Autowired
	IEmployeeDao employeeDao;
	@Override
	public int addEmployee(Employee emp)
	{
		return employeeDao.addEmployee(emp);
		
	}

	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDao.showAllEmployee();
	}

	@Override
	public void deleteEmployee(int empId)
	{
		employeeDao.deleteEmployee(empId);		
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Employee searchEmployee(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

}
