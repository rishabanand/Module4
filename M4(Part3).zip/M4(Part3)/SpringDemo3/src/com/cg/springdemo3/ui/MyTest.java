package com.cg.springdemo3.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemo3.dto.EmployeeDetail;

public class MyTest 
{
	private static ApplicationContext appContext;

	public static void main(String[] args)
	{
		appContext = new ClassPathXmlApplicationContext("Spring.xml");
		EmployeeDetail e=(EmployeeDetail) appContext.getBean("emp");
		e.getAllEmployeeDetail();
	}
}
