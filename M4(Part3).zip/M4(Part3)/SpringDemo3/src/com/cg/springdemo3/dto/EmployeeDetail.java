package com.cg.springdemo3.dto;

public interface EmployeeDetail 
{
	public void getAllEmployeeDetail();	
}
