package com.cg.springdemo4.dao;

import org.springframework.stereotype.Component;

@Component("empDao")
public class EmployeeDaoImpl implements IEmployeeDao
{
	
	@Override
	public void getDao() 
	{
		System.out.println("In Dao Layer");
		
	}

}
