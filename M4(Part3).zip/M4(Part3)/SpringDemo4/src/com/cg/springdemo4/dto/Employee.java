package com.cg.springdemo4.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.springdemo4.service.IEmployeeService;

@Component("emp")
public class Employee 
{
	@Autowired
	IEmployeeService employeeService;
	public void getDetails()
	{
		System.out.println("Welcome to spring Annotation..");
		employeeService.getData();
	}
}
