package com.cg.springdemo4.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.springdemo4.dao.IEmployeeDao;

@Component("employeeService")
public class EmployeeServiceImpl implements IEmployeeService
{
	@Autowired
	IEmployeeDao empDao;
	@Override
	public void getData()
	{
		System.out.println("In Service Layer");
		empDao.getDao();
		
	}

}
