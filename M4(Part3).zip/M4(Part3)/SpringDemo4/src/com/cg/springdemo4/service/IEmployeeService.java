package com.cg.springdemo4.service;

public interface IEmployeeService 
{
	public void getData();
}
