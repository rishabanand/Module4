package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.TraineeDao;
import com.cg.dto.Trainee;

@Service("traineeService")
@Transactional
public class TraineeServiceImpl implements TraineeService
{
	@Autowired
	TraineeDao traineeDao;

	@Override
	public void addEmployee(Trainee trainee)
	{
		traineeDao.addTrainee(trainee);
	}

	@Override
	public void deleteTraineeById(int traineeId) 
	{
		traineeDao.deleteTraineeById(traineeId);		
	}

	@Override
	public Trainee fetchTraineeById(int traineeId)
	{		
		return traineeDao.fetchTraineeById(traineeId);
	}

	@Override
	public List<Trainee> showAllTrainee()
	{		
		return traineeDao.showAllTrainee();
	}

	@Override
	public void updateTrainee(Trainee trainee) 
	{
		traineeDao.updateTrainee(trainee);		
	}
	
}
