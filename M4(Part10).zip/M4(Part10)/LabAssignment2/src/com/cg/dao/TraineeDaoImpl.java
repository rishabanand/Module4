package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.dto.Trainee;
@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDao
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void addTrainee(Trainee trainee) 
	{
		entityManager.persist(trainee);
		entityManager.flush();
	}

	@Override
	public void deleteTraineeById(int traineeId)
	{
		Query queryOne=entityManager.createQuery("DELETE FROM Trainee WHERE traineeId=:traId");	
		queryOne.setParameter("traId",traineeId);
		queryOne.executeUpdate();
	}

	@Override
	public Trainee fetchTraineeById(int traineeId)
	{
		Trainee trainee=entityManager.find(Trainee.class, traineeId);
		return trainee;
	}

	@Override
	public List<Trainee> showAllTrainee()
	{
		Query queryOne=entityManager.createQuery("SELECT t FROM Trainee t");
		List<Trainee> myList= queryOne.getResultList();
		return myList;
		
	}

	@Override
	public void updateTrainee(Trainee trainee) 
	{
		entityManager.merge(trainee);
		entityManager.flush();	
	}

}
