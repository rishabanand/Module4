package com.cg.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController
{
	@Autowired
	TraineeService traineeService;
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String displayLoginPage()
	{
		return "Login";
	}
	@RequestMapping(value="menu",method=RequestMethod.GET)
	public String displayMenu()
	{
		return "Menu";
	}
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addMenu(@ModelAttribute("my") Trainee trainee
			,Map<String,Object> model)
	{
		List<String> myDomain=new ArrayList<>();
		myDomain.add("Java");
		myDomain.add("Dot net");
		myDomain.add("testing");
		model.put("domain",myDomain);
		return "addTrainee";
	}
	@RequestMapping(value="insertTrainee",method=RequestMethod.POST)
	public ModelAndView insertTrainee(@Valid@ModelAttribute("my") Trainee trainee,BindingResult result,Map<String,Object> model)
	{
		if(result.hasErrors())
		{
			List<String> myDomain=new ArrayList<>();
			myDomain.add("Java");
			myDomain.add("Dot net");
			myDomain.add("testing");
			model.put("domain",myDomain);
			return new ModelAndView("addTrainee");
		}
		else
		{
			traineeService.addEmployee(trainee);
		}
		return new ModelAndView("Success");
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String delete()
	{
		return "deleteTrainee";
	}
	@RequestMapping(value="deleteTrainee", method=RequestMethod.GET)
	public ModelAndView fetchTrainee(@RequestParam("id") int tId)
	{
		Trainee trainee=traineeService.fetchTraineeById(tId);
		
		return new ModelAndView("SuccessDelete","temp",trainee);
	}
	@RequestMapping(value="finaldelete",method=RequestMethod.GET)
	public String finalDelete(@RequestParam("id") int tId)
	{
		traineeService.deleteTraineeById(tId);
		return "FinalSuccessDelete";
	}
	@RequestMapping(value="show",method=RequestMethod.GET)
	public String fetchTraineeById()
	{
		return "fetchTrainee";
	}
	@RequestMapping(value="fetchTrainee",method=RequestMethod.GET)
	public ModelAndView fetch(@RequestParam("txtId") int tId)
	{
		Trainee trainee=traineeService.fetchTraineeById(tId);
		return new ModelAndView("FinalFetch","temp", trainee);
	}
	@RequestMapping(value="showAll",method=RequestMethod.GET)
	public ModelAndView fetchAll()	
	{
		List<Trainee> trainees=traineeService.showAllTrainee();
		return new ModelAndView("fetchAllTrainee","temp",trainees);
	}
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String update(@ModelAttribute("my") Trainee trainee)
	{			
		return "updateTrainee";
	}
	@RequestMapping(value="update2",method=RequestMethod.POST)
	public ModelAndView updateForm(@ModelAttribute("my")Trainee trainee,Map<String,Object> model)
	{
		Trainee data=traineeService.fetchTraineeById(trainee.getTraineeId());
		//System.out.println("Data is "+trainee);
		model.put("my",data);
		List<String> myDomain=new ArrayList<>();
		myDomain.add("Java");
		myDomain.add("Dot net");
		myDomain.add("testing");
		model.put("domain",myDomain);
		return new ModelAndView("updateForm");
	}
	@RequestMapping(value="updateTrainee",method=RequestMethod.POST)
	public String updateTraineeById(@ModelAttribute("my") Trainee trainee)
	{
		traineeService.updateTrainee(trainee);
		return "SuccessUpdate";
	}
}
