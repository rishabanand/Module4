package com.cg.dao;



import com.cg.dto.Employee;

public interface EmployeeDao 
{
	public Employee getEmployeeDetailsById(int empId);
}
