package com.cg.dao;

import java.util.List;	



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.dto.Employee;
@Component("empDao")
public class EmployeeDaoImpl implements EmployeeDao
{
	List<Employee> empList;
	
	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	@Autowired
	Employee emp;

	@Override
	public Employee getEmployeeDetailsById(int empId)
	{
		for(Employee tempEmpList:empList)
		{
			if(emp.getEmpId()==empId)
			{				
				emp=tempEmpList;
			}
		}

		return emp;
	}


}
