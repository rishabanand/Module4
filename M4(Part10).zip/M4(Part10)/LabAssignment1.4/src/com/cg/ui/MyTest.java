package com.cg.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.dto.Employee;



class MyTest 
{
	private static ApplicationContext appContext;
	private static Scanner sc;
	private static int empId;
	private static Employee emp;

	public static void main(String[] args)
	{		
		sc = new Scanner(System.in);
		System.out.println("Enter the Employee Id :");
		empId = sc.nextInt();
		
		appContext = new ClassPathXmlApplicationContext("Spring.xml");
		emp = (Employee)appContext.getBean("emp");
		System.out.println("Employee Info");
		emp.printEmpDetails(empId);
		
	}

}
