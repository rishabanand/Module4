package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.dao.EmployeeDaoImpl;
import com.cg.dto.Employee;
@Component("empService")
public class EmployeeServiceImpl implements EmployeeService
{
	
	@Autowired
	EmployeeDaoImpl empDao;

	@Override
	public Employee getEmployeeDetailsById(int empId) 
	{
		
		return empDao.getEmployeeDetailsById(empId);
	}

}
