package com.cg.service;

import com.cg.dto.Employee;

public interface EmployeeService
{
	public Employee getEmployeeDetailsById(int empId);
}
