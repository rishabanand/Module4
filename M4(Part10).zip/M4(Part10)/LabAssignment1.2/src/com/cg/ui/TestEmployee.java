package com.cg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.Employee;

public class TestEmployee {

	private static ApplicationContext appContext;

	public static void main(String[] args)
	{
		appContext = new ClassPathXmlApplicationContext("Spring.xml");
		Employee e=(Employee)appContext.getBean("emp");
		System.out.println("Employee Details");
		System.out.println("-----------------------");
		System.out.println(e);
	}

}
