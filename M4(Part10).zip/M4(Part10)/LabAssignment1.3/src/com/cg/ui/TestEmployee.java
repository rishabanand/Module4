package com.cg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.dto.SBU;

public class TestEmployee {

	private static ApplicationContext appContext;

	public static void main(String[] args)
	{
		appContext = new ClassPathXmlApplicationContext("Spring.xml");
		SBU sbu=(SBU)appContext.getBean("sub");
		System.out.println("SBU details");
		System.out.println("-----------------------------");
		System.out.println(sbu);
		System.out.println("Employee Details:------------");
		sbu.getEmployeeDetail();
	}

}
