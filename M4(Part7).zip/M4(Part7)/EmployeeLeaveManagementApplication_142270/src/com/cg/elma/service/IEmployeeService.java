package com.cg.elma.service;

import java.util.List;
import com.cg.elma.dto.EmployeeLeave;

public interface IEmployeeService 
{
	List<EmployeeLeave> getAllLeaveDetails(Long empId);
	public List<Long> getEmployeeIds();
	public String getEmployeeNameById(Long empId);
	public boolean validateEmployeeId(Long empId);
}
