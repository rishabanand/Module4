package com.cg.elma.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.elma.dao.IEmployeeDao;
import com.cg.elma.dto.EmployeeLeave;

@Service("employeeService")
@Transactional
public class EmployeeService implements IEmployeeService
{
	@Autowired
	IEmployeeDao employeeDao;

	@Override
	public List<EmployeeLeave> getAllLeaveDetails(Long empId) 
	{		
		return employeeDao.getAllLeaveDetails(empId);
	}

	@Override
	public List<Long> getEmployeeIds() 
	{		
		return employeeDao.getEmployeeIds();
	}

	@Override
	public String getEmployeeNameById(Long empId)
	{		
		return employeeDao.getEmployeeNameById(empId);
	}
	@Override
	public boolean validateEmployeeId(Long empId)
	{
		for(Long empIds : employeeDao.getEmployeeIds())
		{
			if(empId.equals(empIds))
			{
				return true;
			}
		}
		return false;
	}

}
