package com.cg.elma.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.elma.dto.EmployeeDetails;
import com.cg.elma.dto.EmployeeLeave;
import com.cg.elma.service.IEmployeeService;

@Controller
public class EmployeeController 
{
	@Autowired
	IEmployeeService employeeService;
	@RequestMapping(value="viewLeaveHistory", method=RequestMethod.GET)
	public String showLeaveAppPage(Model model)
	{	
		model.addAttribute("empDetails",new EmployeeDetails());
		return "Home";
	}

	@RequestMapping(value="viewLeave", method=RequestMethod.GET)
	public ModelAndView viewLeaveHistory(@Valid@ModelAttribute(value="empDetails") EmployeeDetails employeeLeaveDetails,BindingResult result,Map<String,Object> model)
	{
		if(result.hasErrors())
		{
		return new ModelAndView("Home","empDetails",employeeLeaveDetails);
		}
		try
		{
			if(employeeService.validateEmployeeId(employeeLeaveDetails.getEmpId()))
			{
				System.out.println("Id is :"+employeeLeaveDetails.getEmpId());
				String empName=employeeService.getEmployeeNameById(employeeLeaveDetails.getEmpId());
				model.put("empName",empName);
				model.put("empId", employeeLeaveDetails.getEmpId());
				List<EmployeeLeave> employeeLeave=employeeService.getAllLeaveDetails(employeeLeaveDetails.getEmpId());
				System.out.println("Employee Details is : "+employeeLeave);
				return new ModelAndView("ShowAllEmployeeLeaveHistory","temp",employeeLeave);
			}			
			else
			{
				return new ModelAndView("ShowError","temp","This Employee Id Does not exist");
			}			
		}
		catch(Exception e)
		{
			return new ModelAndView("Error","temp",e.getMessage());
		}

	}


}
