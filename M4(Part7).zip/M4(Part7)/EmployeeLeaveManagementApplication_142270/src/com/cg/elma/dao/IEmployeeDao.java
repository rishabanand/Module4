package com.cg.elma.dao;

import java.util.List;
import com.cg.elma.dto.EmployeeLeave;

public interface IEmployeeDao 
{
	List<EmployeeLeave> getAllLeaveDetails(Long empId);
	public List<Long> getEmployeeIds();
	public String getEmployeeNameById(Long empId);
}
