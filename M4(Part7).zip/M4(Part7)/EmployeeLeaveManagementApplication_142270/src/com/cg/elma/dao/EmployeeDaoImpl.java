package com.cg.elma.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.elma.dto.EmployeeLeave;
@Repository("employeeDao")
public class EmployeeDaoImpl implements IEmployeeDao
{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public List<EmployeeLeave> getAllLeaveDetails(Long empId) 
	{
		Query query1=entityManager.createQuery("SELECT empLeave FROM EmployeeLeave empLeave WHERE empId=:employeeId");
		query1.setParameter("employeeId", empId);
		List<EmployeeLeave> empLeaveList=query1.getResultList();
		return empLeaveList;
	}
	@Override
	public List<Long> getEmployeeIds()
	{
		Query query2=entityManager.createQuery("SELECT empId FROM EmployeeDetails");
		return query2.getResultList();
	}
	@Override
	public String getEmployeeNameById(Long empId)
	{
		Query query3=entityManager.createQuery("SELECT employeeName FROM EmployeeDetails WHERE empId=:employeeId");
		query3.setParameter("employeeId", empId);
		return (String) query3.getSingleResult();
	}
	
}
