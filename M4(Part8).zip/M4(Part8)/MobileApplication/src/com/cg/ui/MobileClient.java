package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.dto.Mobile;
import com.cg.service.MobileService;
import com.cg.service.MobileServiceImpl;

public class MobileClient {

	public static void main(String[] args) 
	{
		MobileService mobileService=new MobileServiceImpl();
		Scanner sc=new Scanner(System.in);
		int choice=0;
		Mobile mobile=new Mobile();
		while(true)
		{
		
		System.out.println("1.Add Mobile\n2.Update Mobile\n"
				+ "3.Delete Mobile\n4.Fetch Mobile\n5.Fetch All Mobiles\n6. Fetch All Mobiles within Price Range\n7.Exit");
		System.out.println("\nEnter your choice:");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1: 
			System.out.println("Enter Mobile name");
			sc.nextLine();
			String name=sc.nextLine();
			System.out.println("Enter price");
			double price=sc.nextDouble();
			System.out.println("Enter Quantity :");
			int qty=sc.nextInt();
			mobile.setmName(name);
			mobile.setPrice(price);
			mobile.setQty(qty);
			mobileService.addMobile(mobile);
			System.out.println("Mobile Details added Successfully");
			break;
		case 2:
			System.out.println("Enter the mobileId you want to update:");
			int mId=sc.nextInt();
			System.out.println("Enter the new Mobile Name");
			sc.nextLine();
			String newName=sc.nextLine();
			System.out.println("Enter the newPrice");
			double newPrice=sc.nextDouble();
			System.out.println("Enter the new Quantity");
			int newQty=sc.nextInt();
			Mobile mobile3=new Mobile();
			mobile3.setMobileId(mId);
			mobile3.setmName(newName);
			mobile3.setPrice(newPrice);
			mobile3.setQty(newQty);
			mobileService.updateMobile(mobile3);
			System.out.println("All Data Updated Successfully");
			break;
		case 3:
			System.out.println("Enter mobile Id to delete:");
			int mobileId=sc.nextInt();
			Mobile mobile1=mobileService.findMobile(mobileId);
			mobileService.deleteMobile(mobile1);
			System.out.println("Mobile Deleted Successfully");			
			break;
		case 4:			
			System.out.println("Enter mobile Id to search:");
			int mobileId2=sc.nextInt();
			Mobile mobile2=mobileService.findMobile(mobileId2);
			System.out.println(mobile2);
			break;
		case 5:
			List<Mobile> mobileList=mobileService.getAllMobiles();
			for(Mobile m:mobileList)
			{
				System.out.println(m);
			}
			
			break;
		case 6: 
			System.out.println("Enter the min Price");
			double minPrice=sc.nextDouble();
			System.out.println("Enter the max Price");
			double maxPrice=sc.nextDouble();
			List<Mobile> mobList=mobileService.fetchMobileInPriceRange(minPrice, maxPrice);
			for(Mobile m:mobList)
			{
				System.out.println(m);
			}
			break;
		case 7: System.exit(0);
		}
		}

	}

}
