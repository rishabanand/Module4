package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="mobiles")
@NamedQueries
(
		{
			@NamedQuery(name="Select_All",query="SELECT m FROM Mobile m"),
			@NamedQuery(name="Select_Price_Range",query="SELECT m FROM Mobile m "
				+ "WHERE m.price between :min AND :max")
		}
)
public class Mobile 
{
	@Id
	@SequenceGenerator(name="mobSeq",sequenceName="mob_id_seq",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="mobSeq")
	private int mobileId;
	@Column(name="name")
	private String mName;
	private double price;
	@Column(name="quantity")
	private int qty;
	public Mobile() 
	{
		super();

	}
	public int getMobileId() 
	{
		return mobileId;
	}
	public void setMobileId(int mobileId) 
	{
		this.mobileId = mobileId;
	}

	public String getmName() 
	{
		return mName;
	}
	public void setmName(String mName) 
	{
		this.mName = mName;
	}
	public double getPrice()
	{
		return price;
	}
	public void setPrice(double price)
	{
		this.price = price;
	}
	public int getQty()
	{
		return qty;
	}
	public void setQty(int qty)
	{
		this.qty = qty;
	}
	@Override
	public String toString() 
	{
		return "Mobile [mobileId=" + mobileId + ", mName=" + mName + ", price="
				+ price + ", qty=" + qty + "]";
	}


}
