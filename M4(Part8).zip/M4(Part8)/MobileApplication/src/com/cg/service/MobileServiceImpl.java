package com.cg.service;

import java.util.List;

import com.cg.dao.MobileDao;
import com.cg.dao.MobileDaoImpl;
import com.cg.dto.Mobile;

public class MobileServiceImpl implements MobileService
{
	MobileDao mobileDao;
	public MobileServiceImpl()
	{
		mobileDao=new MobileDaoImpl();
	}
	@Override
	public void addMobile(Mobile mobile) 
	{
		mobileDao.addMobile(mobile);		
	}

	@Override
	public void updateMobile(Mobile mobile)
	{
		mobileDao.updateMobile(mobile);		
	}

	@Override
	public void deleteMobile(Mobile mobile) 
	{
		mobileDao.deleteMobile(mobile);		
	}

	@Override
	public Mobile findMobile(int mid)
	{		
		return mobileDao.findMobile(mid);
	}
	@Override
	public List<Mobile> getAllMobiles() 
	{
		return mobileDao.getAllMobiles();
	}
	@Override
	public List<Mobile> fetchMobileInPriceRange(double minPrice, double maxPrice)
	{
		return mobileDao.fetchMobileInPriceRange(minPrice, maxPrice);
	}


}
