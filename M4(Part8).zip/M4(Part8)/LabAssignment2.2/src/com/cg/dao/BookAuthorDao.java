package com.cg.dao;

import java.util.List;

import com.cg.dto.Book;

public interface BookAuthorDao
{
	List<Book> getAllMobiles();
	List<Book> fetchMobileInPriceRange( double minPrice,double maxPrice);
}
