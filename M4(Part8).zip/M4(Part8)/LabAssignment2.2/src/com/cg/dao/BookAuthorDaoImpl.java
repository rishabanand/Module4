package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.dto.Book;

public class BookAuthorDaoImpl implements BookAuthorDao
{

	EntityManager em;
	public BookAuthorDaoImpl()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		em=emf.createEntityManager();
	}
	@Override
	public List<Book> getAllMobiles() 
	{
		TypedQuery<Book> query=em.createNamedQuery("Select_All",Book.class);
		return query.getResultList();
	}

	@Override
	public List<Book> fetchMobileInPriceRange(double minPrice, double maxPrice) 
	{		
		TypedQuery<Book> query=em.createNamedQuery("Select_Price_Range",Book.class);
		query.setParameter("min",minPrice);
		query.setParameter("max", maxPrice);
		return query.getResultList();
	}

}
