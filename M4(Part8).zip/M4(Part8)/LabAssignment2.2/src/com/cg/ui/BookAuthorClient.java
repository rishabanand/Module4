package com.cg.ui;


import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.Service.BookAuthorService;
import com.cg.Service.BookAuthorServiceImpl;
import com.cg.dto.Authors;
import com.cg.dto.Book;



public class BookAuthorClient {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		BookAuthorService bookAuthorSer=new BookAuthorServiceImpl();
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		int choice=0;
		
		Book book=new Book();
		book.setId(101);
		book.setName("Programming with C");
		
		Book book1=new Book();
		book1.setId(102);
		book1.setName("Programming with C++");
		
		Authors author1=new Authors();
		author1.setISBN("Is2100");
		author1.setTitle("Rishab Publication");
		author1.setPrice(1500.0);
		author1.addBook(book);
		
		Authors author2=new Authors();
		author2.setISBN("Is2101");
		author2.setTitle("Divya Publication");
		author2.setPrice(1400.0);
		author2.addBook(book1);
		 
		em.persist(author1);
		em.persist(author2);/*
		System.out.println("Choose YOUR OPTION : 1.Fetch All Books\n"
				+ "2.Fetch All Books within Price Range");
		switch(choice)
		{
		case 1: 
			List<Book> bookList=bookAuthorSer.getAllMobiles();
			for(Book b:bookList)
			{
				System.out.println(b);
			}
			
			break;
		case 2:
			System.out.println("Enter the min Price");
			double minPrice=sc.nextDouble();
			System.out.println("Enter the max Price");
			double maxPrice=sc.nextDouble();
			List<Book> booksList=bookAuthorSer.fetchMobileInPriceRange(minPrice, maxPrice);
			for(Book b1:booksList)
			{
				System.out.println(b1);
			}
			break;
		}*/
	}

}
