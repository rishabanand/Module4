package com.cg.Service;

import java.util.List;

import com.cg.dto.Book;

public interface BookAuthorService
{
	List<Book> getAllMobiles();
	List<Book> fetchMobileInPriceRange( double minPrice,double maxPrice);
}
