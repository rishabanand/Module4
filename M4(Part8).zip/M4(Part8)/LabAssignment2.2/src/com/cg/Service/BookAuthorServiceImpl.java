package com.cg.Service;

import java.util.List;

import com.cg.dao.BookAuthorDao;
import com.cg.dao.BookAuthorDaoImpl;
import com.cg.dto.Book;

public class BookAuthorServiceImpl implements BookAuthorService
{
	BookAuthorDao bookAuthorDao=new BookAuthorDaoImpl();

	@Override
	public List<Book> getAllMobiles() 
	{
		return bookAuthorDao.getAllMobiles();
	}

	@Override
	public List<Book> fetchMobileInPriceRange(double minPrice, double maxPrice)
	{
		return bookAuthorDao.fetchMobileInPriceRange(minPrice, maxPrice);
	}
	
}
