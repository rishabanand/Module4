package com.cg.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name="book")
@NamedQueries
(
		{
			@NamedQuery(name="Select_All",query="SELECT b FROM book b"),
			@NamedQuery(name="Select_Price_Range",query="SELECT b FROM book b "
				+ "WHERE b.price between :min AND :max")
		}
)
public class Book 
{
	@Id
	private int Id;
	private String name;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "book_author",
	joinColumns = { @JoinColumn(name = "book_id") },
	inverseJoinColumns = { @JoinColumn(name = "author_id") })
	private Set<Authors> books = new HashSet<>();
	public Book() 
	{
		super();
	}
	public Book(int id, String name) 
	{
		super();
		Id = id;
		this.name = name;
	}
	public int getId() 
	{
		return Id;
	}
	public void setId(int id) 
	{
		Id = id;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	
	
}
