package com.cg.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="author")
public class Authors
{
	@Id
	private String ISBN;
	private String title;
	private double price;
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="books")
	private Set<Book> authors = new HashSet<>();
	public Authors() 
	{
		super();
	}
	public String getISBN()
	{
		return ISBN;
	}
	public void setISBN(String iSBN)
	{
		ISBN = iSBN;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title) 
	{
		this.title = title;
	}
	public double getPrice() 
	{
		return price;
	}
	public void setPrice(double price) 
	{
		this.price = price;
	}	
	public Set<Book> getAuthors() 
	{
		return authors;
	}
	public void setAuthors(Set<Book> authors) 
	{
		this.authors = authors;
	}
	public void addBook(Book book) 
	{
		this.getAuthors().add(book);
	}
	public Authors(String iSBN, String title, double price, Set<Book> authors) {
		super();
		ISBN = iSBN;
		this.title = title;
		this.price = price;
		this.authors = authors;
	}
	@Override
	public String toString() 
	{
		return "Authors [ISBN=" + ISBN + ", title=" + title + ", price="
				+ price + ", authors=" + authors + "]";
	}
	
	
	
	
}
