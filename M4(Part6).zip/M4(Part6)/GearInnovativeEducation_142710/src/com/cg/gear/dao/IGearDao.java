package com.cg.gear.dao;

import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;

public interface IGearDao {
	public Gear viewQueryById(int queryId)throws GearException;
	
	public boolean updateQuery(Gear gear)throws GearException; 
}
