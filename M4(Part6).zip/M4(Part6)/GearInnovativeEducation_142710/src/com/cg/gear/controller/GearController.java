package com.cg.gear.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;
import com.cg.gear.service.IGearService;



@Controller
public class GearController {

	@Autowired
	private IGearService gearService;
	
	@RequestMapping(value="show",method=RequestMethod.GET)
	public String showHomePage(@ModelAttribute("myGear") Gear gear)
	{
		/*returns to home page*/
		return "home";
	}
	
	@RequestMapping(value="search",method=RequestMethod.GET)
	public ModelAndView search(@ModelAttribute("myGear") Gear gear,Map<String,Object> model1)
	{
		ModelAndView model = new ModelAndView();
		Gear bean1=new Gear();
		
		try {
			
			/*we are taking the query details based on query id*/
			bean1=gearService.viewQueryById(gear.getQueryId());
			List<String> solvedBy=new ArrayList<>();
			solvedBy.add("Uma");	/* we should not give hardcoded  so we pass through model*/
			solvedBy.add("Rahul");
			solvedBy.add("Kavitha");
			solvedBy.add("Hema");
			model1.put("solvedBy", solvedBy);
			model.addObject("gear",bean1);
			model.setViewName("viewSuccess");
			/*goes to success page*/
			
		} catch (GearException e) {
			
			String errorMessage=e.getMessage();
			return new ModelAndView("error","err",errorMessage);
			
		}
		
		return model;
		
	}
	
		@RequestMapping(value="update",method=RequestMethod.POST)
	public ModelAndView update(@ModelAttribute("myGear") Gear gear){

		ModelAndView model=new ModelAndView();
		try {
			
			gearService.updateQuery(gear);
			return new ModelAndView("updatedSuccessfully","queryId",gear.getQueryId());
						
		} catch (GearException e) 
		{
			/* if not updated raise an exception*/
			model.setViewName("error");
			model.addObject("message","updation failed"+e.getMessage());
			return model;
			
		}
		
	}
}
