package com.cg.gear.service;

import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;



public interface IGearService {
	public Gear viewQueryById(int queryId)throws GearException;
	
	public boolean updateQuery(Gear gear)throws GearException; 
}
