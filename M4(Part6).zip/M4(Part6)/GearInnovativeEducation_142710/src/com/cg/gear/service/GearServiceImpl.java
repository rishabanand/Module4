package com.cg.gear.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.gear.dao.IGearDao;
import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;



@Service
public class GearServiceImpl implements IGearService {
	
	@Autowired
	private IGearDao gearDao;
	
	@Override
	public Gear viewQueryById(int queryId) throws GearException {
		
		return gearDao.viewQueryById(queryId);
	}



	@Override
	public boolean updateQuery(Gear gear) throws GearException {
		
		return gearDao.updateQuery(gear);
	}

}
