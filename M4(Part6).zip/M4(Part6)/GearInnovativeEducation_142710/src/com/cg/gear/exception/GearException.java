package com.cg.gear.exception;

public class GearException extends Exception{

	
	
	public GearException(){
		super();
	}
	
	public GearException(String message){
		super(message);
	}

}
